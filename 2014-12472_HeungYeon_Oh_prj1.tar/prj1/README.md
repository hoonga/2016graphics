#Way to compile

This tar has a Makefile.

use 'make' to make ELF.

use 'make run' to run ELF

#Ways to check Hierarchy

In this program, you can walk around, allowing the camera to view every where you want.

Use 'w, a, s, d' like any fps game to move along the x-z plane.

Use 'space' to move up along the y axis.

Use 'f' to move down along the y axis.

Click and move mouse to change orientation of the camera

This cute GLaDOS model has 3 joints.

To move the first joint use '[' , ']'

To move the second, use '-', '='

To move the third, use '_'(shift'+'-'), '+'('shift'+'=')
